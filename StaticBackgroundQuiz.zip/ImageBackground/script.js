// Store the spelling words, tracking for quiz results, and saved lists
let spellingWords = [];
let incorrectAttempts = {};
let correctWords = [];
let incorrectWords = [];
let savedLists = loadSavedLists(); // Load lists from localStorage

// HTML elements
const wordInput = document.getElementById("wordInput");
const addWordButton = document.getElementById("addWordButton");
const wordList = document.getElementById("wordList");
const makeNewListButton = document.getElementById("makeNewListButton");
const saveWordListButton = document.getElementById("saveWordListButton");
const deleteWordListButton = document.getElementById("deleteWordListButton");
const savedListsDropdown = document.getElementById("savedListsDropdown");
const loadWordListButton = document.getElementById("loadWordListButton");
const startQuizButton = document.getElementById("startQuizButton");
const quizSetupSection = document.getElementById("quizSetupSection");
const quizSection = document.getElementById("quizSection");
const wordToSpell = document.getElementById("wordToSpell");
const speakWordButton = document.getElementById("speakWordButton");
const userAnswer = document.getElementById("userAnswer");
const checkAnswerButton = document.getElementById("checkAnswerButton");
const feedback = document.getElementById("feedback");
const questionNumberDisplay = document.getElementById("questionNumberDisplay");
const quizSummarySection = document.getElementById("quizSummarySection");
const summaryContent = document.getElementById("summaryContent");
const retryIncorrectWordsButton = document.getElementById("retryIncorrectWordsButton");
const restartQuizButton = document.getElementById("restartQuizButton");
const britishVoiceButton = document.getElementById("britishVoiceButton");
const spanishVoiceButton = document.getElementById("spanishVoiceButton");

// Selected voice language (default to British English)
let selectedVoiceLanguage = "en-GB";

// Initialize the app on load
document.addEventListener("DOMContentLoaded", () => {
    console.log("App initialized");
    updateSavedListsDropdown(); // Update dropdown with saved lists
    preloadVoices(); // Preload available voices
    updateWordListDisplay(); // Ensure the word list is displayed
});

// Voice selection buttons
britishVoiceButton.addEventListener("click", () => {
    selectedVoiceLanguage = "en-GB";
    alert("Switched to British Voice");
});

spanishVoiceButton.addEventListener("click", () => {
    selectedVoiceLanguage = "es-ES"; // Spanish (Spain)
    alert("Switched to Spanish Voice");
});

// Update the word list display
function updateWordListDisplay() {
    wordList.innerHTML = "";
    spellingWords.forEach((word) => {
        const li = document.createElement("li");
        li.textContent = word;
        const removeButton = document.createElement("button");
        removeButton.textContent = "Remove";
        removeButton.style.marginLeft = "10px";
        removeButton.addEventListener("click", () => {
            removeWord(word);
        });
        li.appendChild(removeButton);
        wordList.appendChild(li);
    });
}

// Add a word to the current list
addWordButton.addEventListener("click", addWord);
wordInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        event.preventDefault();
        addWord();
    }
});

function addWord() {
    const word = wordInput.value.trim();
    if (word) {
        spellingWords.push(word);
        wordInput.value = "";
        updateWordListDisplay();
        startQuizButton.style.display = "block"; // Show "Start Quiz" button
    }
}

// Remove a word from the list
function removeWord(word) {
    spellingWords = spellingWords.filter((w) => w !== word);
    updateWordListDisplay();
}

// Create a new list
makeNewListButton.addEventListener("click", () => {
    spellingWords = [];
    updateWordListDisplay();
    wordInput.value = "";
    startQuizButton.style.display = "none";
    console.log("New list created");
});

// Save the current list
saveWordListButton.addEventListener("click", () => {
    const listName = prompt("Enter a name for this word list:");
    if (listName) {
        savedLists[listName] = [...spellingWords];
        saveListsToLocalStorage();
        updateSavedListsDropdown();
        alert(`List "${listName}" saved successfully!`);
    }
});

// Delete a selected word list
deleteWordListButton.addEventListener("click", () => {
    const selectedList = savedListsDropdown.value;
    if (selectedList && savedLists[selectedList]) {
        if (confirm(`Are you sure you want to delete the list "${selectedList}"?`)) {
            delete savedLists[selectedList];
            saveListsToLocalStorage();
            updateSavedListsDropdown();
            alert(`List "${selectedList}" deleted.`);
        }
    } else {
        alert("Please select a valid list to delete.");
    }
});

// Load a selected word list
loadWordListButton.addEventListener("click", () => {
    const selectedList = savedListsDropdown.value;
    if (selectedList && savedLists[selectedList]) {
        spellingWords = [...savedLists[selectedList]];
        updateWordListDisplay();
        startQuizButton.style.display = "block"; // Show "Start Quiz" button
    }
});

// Update the dropdown with saved lists
function updateSavedListsDropdown() {
    savedListsDropdown.innerHTML = `<option value="">Select a list...</option>`;
    for (const listName in savedLists) {
        const option = document.createElement("option");
        option.value = listName;
        option.textContent = listName;
        savedListsDropdown.appendChild(option);
    }
}

// Save lists to localStorage
function saveListsToLocalStorage() {
    localStorage.setItem("spellingLists", JSON.stringify(savedLists));
}

// Load lists from localStorage
function loadSavedLists() {
    const lists = localStorage.getItem("spellingLists");
    return lists ? JSON.parse(lists) : {};
}

// Preload voices on page load
function preloadVoices() {
    window.speechSynthesis.onvoiceschanged = () => {
        window.speechSynthesis.getVoices();
    };
}

// Start the quiz
startQuizButton.addEventListener("click", () => {
    console.log("Start Quiz button clicked");

    if (spellingWords.length === 0) {
        alert("Please add words to the list before starting the quiz.");
        return;
    }

    quizSetupSection.style.display = "none";
    quizSection.style.display = "block";
    quizSummarySection.style.display = "none"; // Hide the summary section

    currentWordIndex = 0; // Reset quiz variables
    incorrectAttempts = {};
    correctWords = [];
    incorrectWords = [];
    nextWord(); // Start the quiz
});

// Display the next word in the quiz
let currentWordIndex = 0;

function nextWord() {
    if (currentWordIndex < spellingWords.length) {
        const word = spellingWords[currentWordIndex];
        questionNumberDisplay.textContent = `Question ${currentWordIndex + 1} of ${spellingWords.length}`;
        wordToSpell.textContent = "___";
        userAnswer.value = "";
        feedback.textContent = "";
        speakWord(word); // Speak the word
    } else {
        displayQuizSummary(); // Quiz complete
    }
}

// Speak the word
async function speakWord(word) {
    if (!word) return;

    let wordToSpeak = word;

    // Translate the word if the selected voice language is Spanish
    if (selectedVoiceLanguage === "es-ES") {
        wordToSpeak = await translateWord(word);
    }

    const utterance = new SpeechSynthesisUtterance(wordToSpeak);
    const voices = window.speechSynthesis.getVoices();
    const selectedVoice = voices.find(voice => voice.lang === selectedVoiceLanguage);

    if (selectedVoice) {
        utterance.voice = selectedVoice;
    }

    utterance.rate = 0.9; // Adjust rate for clarity
    utterance.pitch = 1.0; // Standard pitch
    window.speechSynthesis.speak(utterance);
}
// Function to translate a word using an API
async function translateWord(word) {
    const apiUrl = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(word)}&langpair=en|es`;

    try {
        const response = await fetch(apiUrl);
        const data = await response.json();

        if (data && data.responseData && data.responseData.translatedText) {
            return data.responseData.translatedText;
        } else {
            console.error("Translation API failed. Defaulting to the original word.");
            return word;
        }
    } catch (error) {
        console.error("Error fetching translation:", error);
        return word; // Fallback to original word if translation fails
    }
}
// Function to translate a word using an API
async function translateWord(word) {
    const apiUrl = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(word)}&langpair=en|es`;

    try {
        const response = await fetch(apiUrl);
        const data = await response.json();

        if (data && data.responseData && data.responseData.translatedText) {
            return data.responseData.translatedText;
        } else {
            console.error("Translation API failed. Defaulting to the original word.");
            return word;
        }
    } catch (error) {
        console.error("Error fetching translation:", error);
        return word; // Fallback to original word if translation fails
    }
}

//SpeakWordFunction
speakWordButton.addEventListener("click", () => {
    if (spellingWords.length === 0) {
        feedback.textContent = "No word to repeat!";
        return;
    }

    const word = spellingWords[currentWordIndex];
    speakWord(word);
    feedback.textContent = "Word repeated.";
});

// Check the user's answer
checkAnswerButton.addEventListener("click", () => {
    const userSpelling = userAnswer.value.trim().toLowerCase();
    const correctWord = spellingWords[currentWordIndex].toLowerCase();

    if (!userSpelling) {
        feedback.style.color = "red";
        feedback.textContent = "Please enter a word!";
        return;
    }

    if (userSpelling === correctWord) {
        // Correct answer
        feedback.style.color = "green";
        feedback.textContent = "Correct!";
        correctWords.push(spellingWords[currentWordIndex]);

        // Advance to the next word
        currentWordIndex++;
        setTimeout(nextWord, 2000); // Show the next word after 2 seconds
    } else {
        // Incorrect answer
        incorrectAttempts[spellingWords[currentWordIndex]] = (incorrectAttempts[spellingWords[currentWordIndex]] || 0) + 1;

        if (incorrectAttempts[spellingWords[currentWordIndex]] < 3) {
            feedback.style.color = "red";
            feedback.textContent = `Incorrect. Try again! (${incorrectAttempts[spellingWords[currentWordIndex]]} attempts)`;
        } else {
            // Show the correct word after 3 incorrect attempts
            feedback.style.color = "red";
            feedback.textContent = `Incorrect. The correct spelling is: ${spellingWords[currentWordIndex]}`;
            incorrectWords.push(spellingWords[currentWordIndex]);

            // Advance to the next word
            currentWordIndex++;
            setTimeout(nextWord, 2000);
        }
    }
});
// Display the quiz summary after all words are completed
function displayQuizSummary() {
    quizSection.style.display = "none"; // Hide the quiz section
    quizSummarySection.style.display = "block"; // Show the summary section

    // Calculate summary statistics
    const totalWords = spellingWords.length;
    const correctCount = correctWords.length;
    const incorrectCount = incorrectWords.length;
    const percentage = ((correctCount / totalWords) * 100).toFixed(2);

    // Generate summary content
    summaryContent.innerHTML = `
        <h3>Quiz Complete!</h3>
        <p>You spelled <strong>${correctCount}</strong> words correctly and <strong>${incorrectCount}</strong> words incorrectly.</p>
        <p>Your score: <strong>${percentage}%</strong></p>
        <h4>Incorrect Words:</h4>
        <ul>${incorrectWords.map(word => `<li>${word}</li>`).join('')}</ul>
    `;

    // Show appropriate buttons
    retryIncorrectWordsButton.style.display = incorrectWords.length > 0 ? "block" : "none"; // Only show if there are incorrect words
    restartQuizButton.style.display = "block";
}

// Retry the incorrect words
retryIncorrectWordsButton.addEventListener("click", () => {
    if (incorrectWords.length === 0) return;

    // Set the spelling words to the incorrect words and reset tracking
    spellingWords = [...incorrectWords];
    incorrectWords = [];
    incorrectAttempts = {};
    correctWords = [];

    // Restart the quiz
    quizSummarySection.style.display = "none"; // Hide the summary section
    quizSection.style.display = "block"; // Show the quiz section
    currentWordIndex = 0; // Reset index
    nextWord(); // Start with the first word
});

// Restart the quiz from scratch
restartQuizButton.addEventListener("click", () => {
    // Clear all tracking and reset the UI
    spellingWords = [];
    correctWords = [];
    incorrectWords = [];
    incorrectAttempts = {};
    currentWordIndex = 0;

    // Reset UI sections
    quizSummarySection.style.display = "none";
    quizSection.style.display = "none";
    quizSetupSection.style.display = "block";

    // Clear the word list and inputs
    wordList.innerHTML = "";
    wordInput.value = "";
    startQuizButton.style.display = "none";
});

