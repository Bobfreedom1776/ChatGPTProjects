// Store the spelling words, tracking for quiz results, and saved lists
let spellingWords = [];
let incorrectAttempts = {};
let correctWords = [];
let incorrectWords = [];
let savedLists = loadSavedLists(); // Load lists from localStorage

// HTML elements
const wordInput = document.getElementById("wordInput");
const addWordButton = document.getElementById("addWordButton");
const wordList = document.getElementById("wordList");
const makeNewListButton = document.getElementById("makeNewListButton");
const saveWordListButton = document.getElementById("saveWordListButton");
const deleteWordListButton = document.getElementById("deleteWordListButton");
const savedListsDropdown = document.getElementById("savedListsDropdown");
const loadWordListButton = document.getElementById("loadWordListButton");
const startQuizButton = document.getElementById("startQuizButton");
const languageDropdown = document.getElementById("languageDropdown");

// Selected voice language (default to British English)
let selectedVoiceLanguage = "en-GB";

// Initialize the app
document.addEventListener("DOMContentLoaded", () => {
    console.log("App initialized");
    updateSavedListsDropdown();
    preloadVoices();
    updateWordListDisplay();
});

// Preload voices for speech synthesis
function preloadVoices() {
    window.speechSynthesis.onvoiceschanged = () => {
        window.speechSynthesis.getVoices();
    };
}

// Update saved lists dropdown
function updateSavedListsDropdown() {
    savedListsDropdown.innerHTML = `<option value="">Select a list...</option>`;
    for (const listName in savedLists) {
        const option = document.createElement("option");
        option.value = listName;
        option.textContent = listName;
        savedListsDropdown.appendChild(option);
    }
}

// Save and load lists from localStorage
function saveListsToLocalStorage() {
    localStorage.setItem("spellingLists", JSON.stringify(savedLists));
}

function loadSavedLists() {
    const lists = localStorage.getItem("spellingLists");
    return lists ? JSON.parse(lists) : {};
}

// Update word list display
function updateWordListDisplay() {
    wordList.innerHTML = "";
    spellingWords.forEach((word) => {
        const li = document.createElement("li");
        li.textContent = word;
        const removeButton = document.createElement("button");
        removeButton.textContent = "Remove";
        removeButton.style.marginLeft = "10px";
        removeButton.addEventListener("click", () => removeWord(word));
        li.appendChild(removeButton);
        wordList.appendChild(li);
    });
}

// Add a word
addWordButton.addEventListener("click", addWord);
wordInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        event.preventDefault();
        addWord();
    }
});

function addWord() {
    const word = wordInput.value.trim();
    if (word) {
        spellingWords.push(word);
        wordInput.value = "";
        updateWordListDisplay();
        startQuizButton.style.display = "block";
    }
}

// Remove a word
function removeWord(word) {
    spellingWords = spellingWords.filter((w) => w !== word);
    updateWordListDisplay();
}

// Manage saved lists
saveWordListButton.addEventListener("click", () => {
    const listName = prompt("Enter a name for this word list:");
    if (listName) {
        savedLists[listName] = [...spellingWords];
        saveListsToLocalStorage();
        updateSavedListsDropdown();
        alert(`List "${listName}" saved successfully!`);
    }
});

deleteWordListButton.addEventListener("click", () => {
    const selectedList = savedListsDropdown.value;
    if (selectedList) {
        delete savedLists[selectedList];
        saveListsToLocalStorage();
        updateSavedListsDropdown();
        alert(`List "${selectedList}" deleted.`);
    }
});

loadWordListButton.addEventListener("click", () => {
    const selectedList = savedListsDropdown.value;
    if (selectedList) {
        spellingWords = [...savedLists[selectedList]];
        updateWordListDisplay();
        startQuizButton.style.display = "block";
    }
});

// Voice selection dropdown
languageDropdown.addEventListener("change", () => {
    selectedVoiceLanguage = languageDropdown.value;
    console.log("Language set to:", selectedVoiceLanguage);
});
// Quiz functionality
let currentWordIndex = 0;

startQuizButton.addEventListener("click", () => {
    if (spellingWords.length === 0) {
        alert("Add words before starting the quiz.");
        return;
    }
    quizSetupSection.style.display = "none";
    quizSection.style.display = "block";
    currentWordIndex = 0;
    incorrectAttempts = {};
    nextWord();
});

function nextWord() {
    if (currentWordIndex < spellingWords.length) {
        wordToSpell.textContent = "___";
        speakWord(spellingWords[currentWordIndex]);
        feedback.textContent = "";
        userAnswer.value = "";
        questionNumberDisplay.textContent = `Question ${currentWordIndex + 1} of ${spellingWords.length}`;
    } else {
        displayQuizSummary();
    }
}

// Speak word
async function speakWord(word) {
    let wordToSpeak = word;
    if (selectedVoiceLanguage !== "en-GB") {
        wordToSpeak = await translateWord(word, selectedVoiceLanguage);
    }
    const utterance = new SpeechSynthesisUtterance(wordToSpeak);
    const voices = window.speechSynthesis.getVoices();
    const selectedVoice = voices.find((v) => v.lang === selectedVoiceLanguage || v.lang === "en-GB");
    if (selectedVoice) utterance.voice = selectedVoice;
    window.speechSynthesis.speak(utterance);
}

speakWordButton.addEventListener("click", () => {
    if (spellingWords.length > 0) speakWord(spellingWords[currentWordIndex]);
});

// Translate word
async function translateWord(word, targetLanguage) {
    const langCode = targetLanguage.split("-")[0];
    const apiUrl = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(word)}&langpair=en|${langCode}`;
    try {
        const response = await fetch(apiUrl);
        const data = await response.json();
        return data?.responseData?.translatedText || word;
    } catch (error) {
        console.error("Translation failed:", error);
        return word;
    }
}

// Check answer with 3-attempt logic
checkAnswerButton.addEventListener("click", () => {
    const userSpelling = userAnswer.value.trim().toLowerCase();
    const correctWord = spellingWords[currentWordIndex].toLowerCase();

    if (!userSpelling) {
        feedback.style.color = "red";
        feedback.textContent = "Please enter a word!";
        return;
    }

    if (userSpelling === correctWord) {
        feedback.style.color = "green";
        feedback.textContent = "Correct!";
        correctWords.push(spellingWords[currentWordIndex]);
        currentWordIndex++;
        setTimeout(nextWord, 2000);
    } else {
        incorrectAttempts[spellingWords[currentWordIndex]] = (incorrectAttempts[spellingWords[currentWordIndex]] || 0) + 1;
        if (incorrectAttempts[spellingWords[currentWordIndex]] >= 3) {
            feedback.style.color = "red";
            feedback.textContent = `Incorrect! Correct spelling: ${correctWord}`;
            incorrectWords.push(spellingWords[currentWordIndex]);
            currentWordIndex++;
            setTimeout(nextWord, 2000);
        } else {
            feedback.style.color = "red";
            feedback.textContent = `Incorrect. Try again! (${incorrectAttempts[spellingWords[currentWordIndex]]} attempts)`;
        }
    }
});

// Quiz summary
function displayQuizSummary() {
    quizSection.style.display = "none";
    quizSummarySection.style.display = "block";
    summaryContent.innerHTML = `
        <h3>Quiz Complete!</h3>
        <p>Correct: ${correctWords.length}</p>
        <p>Incorrect: ${incorrectWords.length}</p>
    `;
}

// Retry incorrect words
retryIncorrectWordsButton.addEventListener("click", () => {
    if (incorrectWords.length > 0) {
        spellingWords = [...incorrectWords];
        incorrectWords = [];
        currentWordIndex = 0;
        quizSummarySection.style.display = "none";
        quizSection.style.display = "block";
        nextWord();
    }
});

// Restart quiz
restartQuizButton.addEventListener("click", () => {
    spellingWords = [];
    correctWords = [];
    incorrectWords = [];
    currentWordIndex = 0;
    quizSummarySection.style.display = "none";
    quizSection.style.display = "none";
    quizSetupSection.style.display = "block";
    updateWordListDisplay();
});
